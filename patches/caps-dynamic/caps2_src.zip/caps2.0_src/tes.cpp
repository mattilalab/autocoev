#include<BCFasta.h>
#include<file_manip.h>



int main(int argc, char *argv[]){



		Newick * newickReader = new Newick(false);
	


		TreeTemplate<Node> *newtree;
		newtree = newickReader->read("test.tre");


	


		vector<int> nodeids;

		nodeids = newtree->getNodesId();
		

		for(int i=0;i<nodeids.size();++i){
			if(newtree->isLeaf(nodeids[i])){
				int darth = newtree->getFatherId(nodeids[i]);
				newtree->getNode(darth)->removeSon(nodeids[i]);
				ofstream fil1;
				fil1.open("tep.tre");
				newickReader->write(*newtree, fil1);		
				fil1.close();
				exit(-1);
			}

		}
		
		delete newickReader;


}
