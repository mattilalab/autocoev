
#include<iostream>
#include<fstream>
#include"BCFasta.h"
#include"file_manip.h"
#include"caps.h"
#include"create.h"
#include<getopt.h>
#include<math.h>
#include<gsl/gsl_randist.h>
#include<gsl/gsl_rng.h>
#include<gsl/gsl_cdf.h>
#include<gsl/gsl_matrix.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_statistics.h>
#include<sys/time.h>
#include<iomanip>
#include<vector>


		double Correlation(vector<double>& sample_a, vector<double>& sample_b, double& mean_a, double& mean_b);
using namespace std;

int main(){

vector<double> v, y;


v.push_back(2);
v.push_back(4);
v.push_back(5);
v.push_back(1);


y.push_back(2);
y.push_back(4);
y.push_back(5);
y.push_back(4);


			gsl_vector_const_view gsl_x = gsl_vector_const_view_array( &v[0], 4);
			gsl_vector_const_view gsl_y = gsl_vector_const_view_array( &y[0], 4);
cerr << "gsl=" << gsl_stats_correlation(&v[0], 1, &y[0], 1,4) << endl;


double mean_a = average_vec<double>(v);
double mean_b = average_vec<double>(y);
cerr << "my=" << Correlation(v, y, mean_a, mean_b) << endl;;

}




		double Correlation(vector<double>& sample_a, vector<double>& sample_b, double& mean_a, double& mean_b){
			double nominator=0.0, X=0.0, Y=0.0, correl=0.0, test;


			for(unsigned int i=0;i<sample_a.size();++i){
				nominator += (sample_a[i] - mean_a) * (sample_b[i] - mean_b);
				Y += (sample_b[i] - mean_b)* (sample_b[i] - mean_b);
				X += (sample_a[i] - mean_a)*(sample_a[i] - mean_a);
			}

			test = sqrt(X*Y);
			if(test!=0.0){
				correl = (nominator)/test;
			}
			return correl;
		}

