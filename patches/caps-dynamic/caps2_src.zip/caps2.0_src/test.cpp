#include<BCFasta.h>
#include<file_manip.h>


using namespace std;




int main(int argc, char *argv[]){

vector<string> files;



files = Folder_to_vector(argv[1]); 

string pwd;
Pwd(pwd);

	for(int i=0;i<files.size();++i){
		string temp;
		temp = pwd;	
			temp += argv[1];
			temp += "/";
			temp += files[i];
		Fasta_vector fasta1;

		Read_Fasta_vector(temp.c_str(), fasta1);

		fasta1.get_identity_level();
		cerr << "identity=" << fasta1.identity <<  "\tfile=" << files[i] << endl;	



	}



}

